// Store references to MCF markers globally by name
window.markersByName = {};

fetch("static/data/boundary.geojson")
  .then(res => res.json())
  .then(data => {
    L.geoJSON(data, {
      pointToLayer: function (feature, latlng) {
        return L.circleMarker(latlng, {
          radius: 10,
          color: "green",
          weight: 2,
          fillColor: "green",
          fillOpacity: 1
        });
      },
      onEachFeature: function (feature, layer) {
        if (feature.properties && feature.properties.name) {
          layer.bindPopup(feature.properties.name);
        }
      }
    }).addTo(map);
  });

fetch("static/data/mcf.geojson")
  .then(res => res.json())
  .then(data => {
    const greenIcon = L.icon({
      iconUrl: 'static/icons/green.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    });

    L.geoJSON(data, {
      pointToLayer: function (feature, latlng) {
        const marker = L.marker(latlng, { icon: greenIcon });
        const name = feature.properties.Name;
        if (name) {
          window.markersByName[name] = marker;
        }
        return marker;
      },
      onEachFeature: function (feature, layer) {
  if (feature.properties && feature.properties.Name) {
  const popupContent = `
    <strong>${feature.properties.Name}</strong><br/>
    Status: (not filled)
  `;
  layer.bindPopup(popupContent);
}

}

    }).addTo(map);
  });

fetch("static/data/RRzf.geojson")
  .then(res => res.json())
  .then(data => {
    const greenIcon = L.icon({
      iconUrl: 'static/icons/green.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    });

    L.geoJSON(data, {
      pointToLayer: function (feature, latlng) {
        return L.marker(latlng, { icon: greenIcon });
      },
      onEachFeature: function (feature, layer) {
  if (feature.properties && feature.properties.Name) {
  const popupContent = `
    <strong>${feature.properties.Name}</strong><br/>
    Status: (updating...)
  `;
  layer.bindPopup(popupContent);
}

}

    }).addTo(map);
  });
