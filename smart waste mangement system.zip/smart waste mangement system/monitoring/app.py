from flask import Flask,render_template,jsonify
import mysql.connector

app = Flask(__name__)
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="smartcity"
    )




@app.route('/')
def monitoring():
    return render_template('index.html')

@app.route('/api/status')
def latest_status():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    
    cursor.execute("""
        SELECT ms.*
        FROM mcf_status ms
        INNER JOIN (
            SELECT name, MAX(id) AS latest_id
            FROM mcf_status
            GROUP BY name
        ) grouped_ms
        ON ms.name = grouped_ms.name AND ms.id = grouped_ms.latest_id;
    """)

    results = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return jsonify(results)


if __name__=="__main__":
    app.run(debug=True,port=8000)