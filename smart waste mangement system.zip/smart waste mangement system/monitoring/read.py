from pyzbar.pyzbar import decode
from PIL import Image

# Path to the QR code image
image_path = "Fort Garage.png"  # Replace with your actual image filename

# Open the image
img = Image.open(image_path)

# Decode the QR code
decoded_objects = decode(img)

# Print the decoded data
for obj in decoded_objects:
    print("QR Code Data:", obj.data.decode('utf-8'))
