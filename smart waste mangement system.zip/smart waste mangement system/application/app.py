from flask import Flask, render_template, request, redirect, session, url_for, jsonify
import mysql.connector
import re
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'smartwaste_secret'

def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="smartcity"
    )

def is_password_valid(password):
    return re.search(r"[A-Za-z]", password) and re.search(r"[0-9]", password)

@app.route('/')
def login_page():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']
    selected_role = request.form['role']

    if not is_password_valid(password):
        return "❌ Password must contain both letters and numbers."

    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cursor.fetchone()
    cursor.close()
    db.close()

    if user and user['password'] == password and user['role'] == selected_role:
        session['email'] = user['email']
        session['role'] = user['role']
        if user['role'] == 'Admin':
            return redirect(url_for('monitoring'))
        elif user['role'] == 'First-Level Staff':
            return redirect(url_for('first_level_page'))
        elif user['role'] == 'Second-Level Staff':
            return redirect(url_for('dashboard'))
        else:
            return redirect('/')

    else:
        return "❌ Invalid login: Check your email, password, or role."

@app.route('/map')
def dashboard():
    if 'email' not in session:
        return redirect('/')
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT name FROM mcf_status WHERE status = 'filled'")
    rows = cursor.fetchall()
    cursor.close()
    db.close()

    filledMCFs = [row['name'] for row in rows]

    return render_template('dashboard.html', email=session['email'], role=session['role'], filledMCFs=filledMCFs)

@app.route('/monitoring')
def monitoring():
    if 'role' not in session or session['role'] != 'Admin':
        return redirect('/')
    return render_template('Adminpage.html', email=session['email'])

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/check-mcf-status', methods=['POST'])
def check_mcf_status():
    if 'role' not in session:
        return jsonify({"success": False, "message": "Not authenticated"})

    data = request.get_json()
    name = data.get('name')
    role = session['role']

    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT status FROM mcf_status WHERE name = %s", (name,))
    result = cursor.fetchone()

    if not result:
        cursor.close()
        db.close()
        return jsonify({"success": False, "message": f"❌ MCF ID '{name}' not found", "exists": False})
    print(result)
    current_status = result['status'].lower()

    response = {
        "success": True,
        "exists": True,
        "name": name,
        "status": current_status
    }

    if role == "Second-Level Staff" and current_status == "filled":
        cursor.execute("UPDATE status SET filled = 'unfilled' WHERE name = %s", (name,))
        db.commit()
        response["status"] = "unfilled"
        response["message"] = f"{name} marked as unfilled"
        response["updated"] = True
        response["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    else:
        response["updated"] = False
        response["message"] = f"{name} is already {current_status}"
    cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify(response)

@app.route('/first-level')
def first_level_page():
    if 'role' not in session or session['role'] != 'First-Level Staff':
        return redirect('/')
    return render_template('first_level_dashboard.html', role=session['role'])

@app.route('/scan-mcf', methods=['POST'])
def scan_mcf():
    data = request.get_json()
    name = data.get("name")

    if not name:
        return jsonify({"success": False, "message": "No MCF name provided"}), 400

    # Get current date and time
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d %H:%M:%S")

    try:
        conn = get_db()
        cursor = conn.cursor(dictionary=True)
        cursor1=conn.cursor(dictionary=True)
        cursor1.execute("SELECT status FROM mcf_status WHERE name=%s ORDER BY id DESC LIMIT 1", (name,))
        result = cursor1.fetchone()
        more_rows=cursor1.fetchall()
        if result is None:
            status=None
        else:
            status=result['status']
        print(status,result)
        if(status=='unfilled'):
            return jsonify({"success": False,"message": f"mcf {name} is already marked as unfilled"})
        # Insert new status as unfilled
        cursor.execute("""
            INSERT INTO mcf_status (name, status, last_update)
            VALUES (%s, %s, %s)
        """, (name, "unfilled", date_str))
        cursor1.close()
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"success": True, "message": f"Marked {name} as unfilled"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/first-scan', methods=['POST'])
def scan_level1_mcf():
    data = request.get_json()
    name = data.get("name")

    if not name:
        return jsonify({"success": False, "message": "No MCF name provided"}), 400

    # Get current date and time
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d %H:%M:%S")

    try:
        conn = get_db()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT status FROM mcf_status WHERE name=%s ORDER BY id DESC LIMIT 1", (name,))
        result=cursor.fetchone()
        if result is None:
            status="not_available"
        else:
            status=result['status']
        if(status=='filled'):
            return jsonify({"success":False,"message":f"MCF' {name}' is already filled"})

        # Insert new status as unfilled
        cursor.execute("""
            INSERT INTO mcf_status (name, status, last_update)
            VALUES (%s, %s, %s)
        """, (name, "filled", date_str))
        more_rows=cursor.fetchall()
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"success": True, "message": f"Marked {name} as filled"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/table-update')
def get_latest_status():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
    SELECT ms.*
    FROM mcf_status ms
    INNER JOIN (
        SELECT name, MAX(id) AS latest_id
        FROM mcf_status
        GROUP BY name
    ) grouped_ms
    ON ms.name = grouped_ms.name AND ms.id = grouped_ms.latest_id
    ORDER BY ms.name;
    """)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(rows)

@app.route('/api/status')
def latest_status():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)

    
    cursor.execute("""
        SELECT ms.*
        FROM mcf_status ms
        INNER JOIN (
            SELECT name, MAX(id) AS latest_id
            FROM mcf_status
            GROUP BY name
        ) grouped_ms
        ON ms.name = grouped_ms.name AND ms.id = grouped_ms.latest_id;
    """)

    results = cursor.fetchall()
    cursor.close()
    conn.close()
    
    return jsonify(results)


if __name__ == '__main__':
    app.run(debug=True,port=4000)
