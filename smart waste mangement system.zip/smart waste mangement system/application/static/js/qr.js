// QR Scanner Logic
    let qrScanner = null;
    function startQr() {
  qrScanner = new Html5Qrcode("qr-reader");
  const config = { fps: 10, qrbox: 250 };

  qrScanner.start(
    { facingMode: "environment" },
    config,
    qrCodeMessage => {
      qrScanner.stop().then(() => {
        const mcfName = qrCodeMessage;

        // Send to Flask
        fetch("/scan-mcf", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: mcfName })
        })
        .then(res => res.json())
        .then(data => {
          alert("✅ Server response: " + data.message);
        })
        .catch(err => {
          console.error("Error sending to Flask:", err);
        });
      });
    },
    error => {
      console.warn("QR scan error:", error);
    }
  ).catch(err => {
    console.error("Unable to start QR scanner:", err);
  });
}

// Run immediately and every 10 seconds
window.addEventListener('load', () => {
  updateMCFStatus();
  setInterval(updateMCFStatus, 10000);
});


function openScanner() {
  if (qrScanner) {
    qrScanner.stop().then(() => {
      qrScanner.clear().then(() => startQr());
    });
  } else {
    startQr();
  }
}

