// Define red and green icons
const redIcon = L.icon({
  iconUrl: 'static/icons/red.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const greenIcon = L.icon({
  iconUrl: 'static/icons/green.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Function to update markers
function updateMCFStatus() {
  fetch('/api/status')
    .then(res => res.json())
    .then(data => {
      data.forEach(entry => {
        const name = entry.name;
        const status = entry.status;
        const marker = window.markersByName[name];

        if (marker) {
          // Update icon based on status
          if (status.toLowerCase() === 'filled') {
            marker.setIcon(redIcon);
          } else {
            marker.setIcon(greenIcon);
          }

          // Update popup content
          const popupContent = `
            <strong>${name}</strong><br/>
            Status: ${status}
          `;
          marker.bindPopup(popupContent);
        }
      });
    })
    .catch(err => {
      console.error("Failed to fetch MCF status:", err);
    });
}

// Run immediately and every 10 seconds
window.addEventListener('load', () => {
  updateMCFStatus();
  setInterval(updateMCFStatus, 1000);
});
