function update_table(){
fetch('/table-update')
.then(res => res.json())
.then(data => {
const tbody = document.querySelector('#mcf-table tbody');
tbody.innerHTML = '';
data.forEach(entry => {
const row = document.createElement('tr');
row.innerHTML = `<td>${entry.name}</td><td>${entry.status}</td><td>${entry.last_update}</td>` ;
tbody.appendChild(row);
});
})
.catch(err => {
console.error("Failed to load MCF status:", err);
});
}

// Run immediately and every 10 seconds
window.addEventListener('load', () => {
  updateMCFStatus();
  setInterval(update_table, 1000);
});