// ✅ Initialize the Leaflet map
const map = L.map("map").setView([8.5241, 76.9366], 13);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "&copy; OpenStreetMap contributors"
}).addTo(map);

// ✅ Fetch MCF data and update table + map markers
function loadMCFData() {
  fetch("/mcf-table")
    .then(res => res.json())
    .then(data => {
      const tbody = document.querySelector("#mcf-table tbody");
      tbody.innerHTML = ""; // clear table first

      data.forEach(row => {
        // 🟩 Add row to table
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${row.id}</td>
          <td>${row.name}</td>
          <td>${row.status}</td>
          <td>${new Date(row.last_update).toLocaleString()}</td>
        `;
        tbody.appendChild(tr);
        // Coordinates lookup (temporary hardcoded)
const mcfCoordinates = {
  "Fort MCF": [8.4801, 76.9421],
  "Fort Garage": [8.4798, 76.9432],
  "Sreekandeshwaram MCF": [8.4880, 76.9435],
  "Chala MCF": [8.4865, 76.9488],
  "Chala MCF2": [8.4868, 76.9490],
  "Attakulangara MCF": [8.4835, 76.9449],
  "Chenthitta MCF": [8.4821, 76.9480],
  "Manacaud MCF": [8.4780, 76.9470]
};

if (mcfCoordinates[row.name]) {
  const latlng = mcfCoordinates[row.name];
  L.circleMarker(latlng, {
    radius: 7,
    fillColor: row.status === "filled" ? "red" : "green",
    color: "#000",
    weight: 1,
    fillOpacity: 0.8
  }).addTo(map).bindPopup(`<b>${row.name}</b><br>Status: ${row.status}`);
}


        // 🟥 Add marker if location is available
        if (row.latitude && row.longitude) {
          L.circleMarker([row.latitude, row.longitude], {
            radius: 8,
            fillColor: row.status === "filled" ? "red" : "green",
            color: "#000",
            weight: 1,
            fillOpacity: 0.8
          }).addTo(map)
          .bindPopup(`<b>${row.name}</b><br>Status: ${row.status}`);
        }
      });
    })
    .catch(err => {
      console.error("Failed to fetch MCF data:", err);
    });
}

// ✅ Run on page load
document.addEventListener("DOMContentLoaded", loadMCFData);
